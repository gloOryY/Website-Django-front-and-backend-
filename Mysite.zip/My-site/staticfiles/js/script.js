document.addEventListener('DOMContentLoaded', function() {
    // Слайдер
    const slides = document.querySelectorAll("#slides .slide");
    if (slides.length > 0) {
        let currentSlide = 0;
        let slideInterval = setInterval(nextSlide, 2000);
        let playing = true;

        function nextSlide() {
            goToSlide(currentSlide + 1);
        }

        function previousSlide() {
            goToSlide(currentSlide - 1);
        }

        function goToSlide(n) {
            slides[currentSlide].className = 'slide';
            currentSlide = (n + slides.length) % slides.length;
            slides[currentSlide].className = 'slide showing';
        }

        // Управление слайдером
        const pauseButton = document.getElementById("pause");
        const nextButton = document.getElementById("next");
        const previousButton = document.getElementById("previous");

        if (pauseButton && nextButton && previousButton) {
            function pauseSlideshow() {
                pauseButton.textContent = 'Продолжить';
                playing = false;
                clearInterval(slideInterval);
            }

            function playSlideshow() {
                pauseButton.textContent = 'Пауза';
                playing = true;
                slideInterval = setInterval(nextSlide, 2000);
            }

            pauseButton.onclick = function() {
                if (playing) pauseSlideshow();
                else playSlideshow();
            };

            nextButton.onclick = function() {
                pauseSlideshow();
                nextSlide();
            };

            previousButton.onclick = function() {
                pauseSlideshow();
                previousSlide();
            };
        }
    }

    // Валидация формы в реальном времени
    const feedbackForm = document.getElementById('feedbackForm');
    if (feedbackForm) {
        feedbackForm.querySelectorAll('input, textarea').forEach(input => {
            input.addEventListener('input', function() {
                if (this.checkValidity()) {
                    this.classList.remove('invalid');
                    this.classList.add('valid');
                } else {
                    this.classList.remove('valid');
                    this.classList.add('invalid');
                }
            });
        });
    }
});