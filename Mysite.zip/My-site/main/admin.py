from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Slide, Comment

class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff')
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Персональная информация', {'fields': ('first_name', 'last_name', 'email')}),
        ('Права', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Важные даты', {'fields': ('last_login', 'date_joined')}),
    )

class SlideAdmin(admin.ModelAdmin):
    list_display = ('title', 'order')
    list_editable = ('order',)

admin.site.register(User, CustomUserAdmin)
admin.site.register(Slide, SlideAdmin)
admin.site.register(Comment)