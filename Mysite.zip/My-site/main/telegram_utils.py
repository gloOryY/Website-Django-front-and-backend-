import requests
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

def send_telegram_message(text):
    if not settings.TELEGRAM_BOT_TOKEN:
        logger.error("❌ TELEGRAM_BOT_TOKEN не настроен!")
        return False

    if not settings.TELEGRAM_CHAT_ID:
        logger.error("❌ TELEGRAM_CHAT_ID не настроен!")
        return False

    url = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage"

    payload = {
        'chat_id': settings.TELEGRAM_CHAT_ID,
        'text': text,
        'parse_mode': 'HTML'
    }

    try:
        logger.info(f"Отправка в Telegram: {text[:50]}...")
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()

        logger.info(f"✅ Успешно отправлено в Telegram! Ответ: {response.json()}")
        return True

    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Ошибка Telegram API: {e}\nURL: {url}\nPayload: {payload}")
        return False