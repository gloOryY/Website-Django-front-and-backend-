from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.core.cache import cache
from .forms import RegisterForm, CommentForm
from .models import Slide, Comment
from .telegram_utils import send_telegram_message
from django.views.decorators.csrf import csrf_exempt
import json

from django.contrib.auth import logout

from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_protect

from django.utils import timezone

from django.shortcuts import get_object_or_404

from django.http import HttpResponseBadRequest

from django.template.loader import render_to_string

from django.middleware.csrf import get_token

def custom_logout(request):
    logout(request)
    return redirect('home')  # Перенаправление на главную

from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import ensure_csrf_cookie
from .telegram_utils import send_telegram_message

@require_POST
def feedback_view(request):
    try:
        name = request.POST.get('name', '').strip()
        email = request.POST.get('email', '').strip()
        message = request.POST.get('message', '').strip()

        if not all([name, email, message]):
            return JsonResponse({
                'status': 'error',
                'message': 'Все поля обязательны'
            })

        telegram_msg = (
            f"📢 Новое сообщение с сайта\n"
            f"👤 Имя: {name}\n"
            f"📧 Email: {email}\n"
            f"💬 Сообщение: {message}"
        )

        if send_telegram_message(telegram_msg):
            return JsonResponse({
                'status': 'success',
                'message': 'Сообщение успешно отправлено'
            })
        else:
            return JsonResponse({
                'status': 'error',
                'message': 'Ошибка отправки сообщения'
            })

    except Exception as e:
        print(f"Ошибка обработки формы: {str(e)}")
        return JsonResponse({
            'status': 'error',
            'message': 'Ошибка обработки запроса'
        })

def home(request):
    slides = Slide.objects.all().order_by('order')
    return render(request, 'home.html', {'slides': slides})

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})

def check_telegram_bot(request):
    from .telegram_utils import send_telegram_message
    test_msg = "🔔 Тестовое сообщение от сервера"
    result = send_telegram_message(test_msg)
    return JsonResponse({"status": "success" if result else "error"})

@csrf_exempt
def notification_handler(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            # Ваша логика обработки уведомлений
            return JsonResponse({'status': 'success'})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
    return JsonResponse({'error': 'Invalid method'}, status=405)

def get_comments(request):
    comments = Comment.objects.select_related('user').all()
    html = render_to_string('comments_list.html', {'comments': comments})
    return JsonResponse({'html': html})

@login_required
@require_POST
def add_comment(request):
    form = CommentForm(request.POST)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.user = request.user
        comment.created_at = timezone.now()
        comment.save()
        html = render_to_string('single_comment.html', {'comment': comment})
        return JsonResponse({'status': 'success', 'html': html})
    else:
        return JsonResponse({'status': 'error', 'errors': form.errors}, status=400)