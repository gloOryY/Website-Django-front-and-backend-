
from http.server import SimpleHTTPRequestHandler, HTTPServer
import os

PORT = 5000
STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'staticfiles')

class StaticHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=STATIC_DIR, **kwargs)

def run():
    server = HTTPServer(('0.0.0.0', PORT), StaticHandler)
    print(f"Static server running on port {PORT}")
    server.serve_forever()

if __name__ == '__main__':
    run()
