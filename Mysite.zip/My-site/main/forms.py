from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Comment

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')

    def clean_first_name(self):
        first_name = self.cleaned_data.get('first_name')
        if not first_name.istitle() or not first_name.isalpha():
            raise forms.ValidationError('Имя должно начинаться с заглавной буквы и содержать только буквы')
        return first_name

    def clean_last_name(self):
        last_name = self.cleaned_data.get('last_name')
        if not last_name.istitle() or not last_name.isalpha():
            raise forms.ValidationError('Фамилия должна начинаться с заглавной буквы и содержать только буквы')
        return last_name

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'placeholder': 'Ваш отзыв...', 'rows': 3}),
        }
        labels = {
            'text': '',
        }