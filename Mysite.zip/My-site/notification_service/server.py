
from flask import Flask, request, jsonify
import os
import requests

app = Flask(__name__)

TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')

@app.route('/send', methods=['POST'])
def send_notification():
    data = request.json
    message = data.get('message')
    
    telegram_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    params = {
        'chat_id': TELEGRAM_CHAT_ID,
        'text': message
    }
    
    response = requests.post(telegram_url, json=params)
    return jsonify({'status': 'success' if response.ok else 'error'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
