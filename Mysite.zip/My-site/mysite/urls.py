from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from main import views
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('feedback/', views.feedback_view, name='feedback'),
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('test-telegram/', views.check_telegram_bot),
    path('accounts/', include('django.contrib.auth.urls')),
    path('register/', views.register, name='register'),
    path('logout/', LogoutView.as_view(next_page='home'), name='logout'),
    path('notify/', views.notification_handler, name='notify'),
    path('comments/', views.get_comments, name='get_comments'),
    path('add_comment/', views.add_comment, name='add_comment'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static('/static/', base_url='http://0.0.0.0:5000')
